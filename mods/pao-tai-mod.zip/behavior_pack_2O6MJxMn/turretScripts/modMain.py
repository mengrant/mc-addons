# -*- coding: utf-8 -*-
from mod.common.mod import Mod
import mod.server.extraServerApi as serverApi

MOD_NAME = "TurretMod"
SERVER_SYSTEM_NAME = "TurretServerSystem"
SERVER_SYSTEM_CLS_PATH = "turretScripts.turretServerSystem.TurretServerSystem"


@Mod.Binding(name=MOD_NAME, version="0.0.5")
class TurretMod(object):

    def __init__(self):
        pass

    @Mod.InitServer()
    def TurretServerInit(self):
        serverApi.RegisterSystem(MOD_NAME, SERVER_SYSTEM_NAME, SERVER_SYSTEM_CLS_PATH)

    @Mod.DestroyServer()
    def TurretServerDestroy(self):
        pass
