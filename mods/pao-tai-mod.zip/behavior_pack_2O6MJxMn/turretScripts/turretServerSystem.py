# -*- coding: utf-8 -*-
"""
自动炮塔 - 服务端逻辑

方块：turret:turret（自动炮塔基座）

操作
  空手右键      循环切换工作模式：待机 -> 警戒(敌对生物) -> 清剿(所有生物) -> 无差别(含玩家)
  弹药          无限（UNLIMITED_AMMO=True），不需要装填；手持箭右键只会得到提示
  提示里始终带当前模式，不用另开界面查

遥控器（物品 turret:remote）
  手持遥控器右键炮塔      绑定（弹药无限时不再承担补弹职责）
  手持遥控器右键其它炮塔  改绑到该炮塔（相当于解绑旧目标）
  绑定后右键其它方块      远程循环切换该炮塔模式，提示里带模式/距离
  遥控半径 64 格、必须同维度；目标炮塔被拆会自动解绑

战斗
  半径 16 格内选最近的合法目标；
  按固定节奏发射一支「追踪箭」（引擎抛射物，带 targetId = 跟踪导弹同款追踪），
  伤害、弹道、命中判定全部交给引擎，脚本只负责"锁谁、往哪打、扣弹药"。

实现要点
  * 弹药与模式存方块实体数据，随存档持久化；
  * 弹药无限（UNLIMITED_AMMO），射出的箭 5 秒后自动销毁，不会满地插箭；
  * tick 处理按坐标哈希错峰，多个炮塔不会挤在同一帧开火；
  * 抛射物需要一个创建者实体，这里取最近的玩家当 spawner（isDamageOwner=False，不会伤到人），
    附近没有玩家时就不空放箭；
  * 目标实体组件做缓存并限长，避免高频 tick 反复创建组件。
"""

import math
import time

import mod.server.extraServerApi as serverApi

ServerSystem = serverApi.GetServerSystemCls()

LEVEL_ID = serverApi.GetLevelId()
FACTORY = serverApi.GetEngineCompFactory()

BLOCK_NAME = "turret:turret"

KEY_AMMO = "ammo"
KEY_MODE = "mode"

MAX_AMMO = 96
AMMO_PER_ARROW = 8
UNLIMITED_AMMO = True      # 弹药无限：不消耗、不用装填；改回 False 即恢复有限弹药
ARROW_ITEM = "minecraft:arrow"
INV_SLOTS = 36             # 背包槽位数（含快捷栏），远程补弹时按槽扫描
DEFAULT_AMMO = 16          # 刚放下时给一点"试用装"
AMMO_DEFAULT_ON_LOAD = 8

SCAN_RADIUS = 16.0
SCAN_RADIUS_SQ = SCAN_RADIUS * SCAN_RADIUS

PROCESS_INTERVAL = 2       # 每 2 tick 处理一次
FIRE_INTERVAL = 8          # 每 8 tick（0.4 秒）最多打一发

ARROW_DAMAGE = 6.0
ARROW_POWER = 2.6
ARROW_GRAVITY = 0.03
ARROW_LIFETIME = 100      # 炮塔射出的箭最多存在 100 tick（5 秒），到期自动销毁，战场不留插地的箭

USE_THROTTLE = 6

# 遥控器
REMOTE_ITEM = "turret:remote"
REMOTE_RANGE = 64.0
REMOTE_RANGE_SQ = REMOTE_RANGE * REMOTE_RANGE
REMOTE_THROTTLE = 0.25      # 秒，防止一次点击被两个事件重复处理
KEY_BIND = "turret_remote_bind"

MODE_OFF = 0
MODE_MONSTER = 1
MODE_MOB = 2
MODE_ALL = 3
MODE_COUNT = 4

MODE_TEXT = {
    MODE_OFF: u"待机",
    MODE_MONSTER: u"警戒（只打敌对生物）",
    MODE_MOB: u"清剿（所有生物）",
    MODE_ALL: u"无差别（含玩家）",
}

# 敌对生物名单（模式 1 用）。只认这些，避免把牛羊当敌人打
MONSTERS = frozenset([
    "minecraft:zombie", "minecraft:husk", "minecraft:drowned", "minecraft:zombie_villager",
    "minecraft:skeleton", "minecraft:stray", "minecraft:wither_skeleton", "minecraft:bogged",
    "minecraft:creeper", "minecraft:spider", "minecraft:cave_spider", "minecraft:silverfish",
    "minecraft:endermite", "minecraft:slime", "minecraft:magma_cube", "minecraft:witch",
    "minecraft:pillager", "minecraft:vindicator", "minecraft:evoker", "minecraft:ravager",
    "minecraft:vex", "minecraft:phantom", "minecraft:blaze", "minecraft:ghast",
    "minecraft:enderman", "minecraft:shulker", "minecraft:guardian", "minecraft:elder_guardian",
    "minecraft:piglin", "minecraft:piglin_brute", "minecraft:zombified_piglin",
    "minecraft:hoglin", "minecraft:zoglin", "minecraft:wither", "minecraft:ender_dragon",
    "minecraft:warden", "minecraft:breeze",
])

PLAYER_TYPE = "minecraft:player"

# 抛射物找 spawner 时的搜索半径
SPAWNER_RADIUS = 64.0


def _dist2(a, b):
    dx = a[0] - b[0]
    dy = a[1] - b[1]
    dz = a[2] - b[2]
    return dx * dx + dy * dy + dz * dz


def _itemName(itemDict):
    if not itemDict:
        return ""
    return itemDict.get("newItemName") or itemDict.get("itemName") or ""


def _ammoText(ammo):
    if UNLIMITED_AMMO:
        return u"弹药 ∞"
    return u"弹药 %d/%d" % (ammo, MAX_AMMO)


class TurretServerSystem(ServerSystem):

    def __init__(self, namespace, systemName):
        ServerSystem.__init__(self, namespace, systemName)
        self.blockEntity = FACTORY.CreateBlockEntityData(LEVEL_ID)
        self.blockInfo = FACTORY.CreateBlockInfo(LEVEL_ID)
        self.game = FACTORY.CreateGame(LEVEL_ID)
        self.itemComp = FACTORY.CreateItem(LEVEL_ID)
        self.msgComp = FACTORY.CreateMsg(LEVEL_ID)
        self.projComp = FACTORY.CreateProjectile(LEVEL_ID)

        self.processTick = 0
        self.useSeq = 0
        self.lastUse = {}
        self.remoteGuard = {}
        self.trackedArrows = []   # [(projectId, birthTick)]，到期销毁，战场不留箭
        self.posCache = {}
        self.typeCache = {}

        engineNs = serverApi.GetEngineNamespace()
        engineSys = serverApi.GetEngineSystemName()
        self.ListenForEvent(engineNs, engineSys, "ServerBlockEntityTickEvent", self, self.OnBlockEntityTick)
        self.ListenForEvent(engineNs, engineSys, "ServerBlockUseEvent", self, self.OnBlockUse)
        self.ListenForEvent(engineNs, engineSys, "ServerItemUseOnEvent", self, self.OnItemUseOn)
        self.ListenForEvent(engineNs, engineSys, "ServerPlaceBlockEntityEvent", self, self.OnPlaceBlockEntity)

    # ------------------------------------------------------------------ #
    # 事件
    # ------------------------------------------------------------------ #
    def OnPlaceBlockEntity(self, args):
        if args.get("blockName") != BLOCK_NAME:
            return
        pos = (args["posX"], args["posY"], args["posZ"])
        dim = args["dimension"]
        self._write(dim, pos, KEY_AMMO, DEFAULT_AMMO)
        self._write(dim, pos, KEY_MODE, MODE_MONSTER)

    def OnBlockEntityTick(self, args):
        try:
            if args.get("blockName") != BLOCK_NAME:
                return
            self.processTick += 1
            x, y, z = args["posX"], args["posY"], args["posZ"]
            salt = (x * 31 + y * 17 + z * 13) & 0xFFFF
            if (self.processTick + salt) % PROCESS_INTERVAL != 0:
                return

            dim = args["dimension"]
            pos = (x, y, z)
            self._sweepArrows()
            mode = self._read(dim, pos, KEY_MODE, MODE_MONSTER)
            if mode == MODE_OFF:
                return
            if not UNLIMITED_AMMO:
                ammo = self._read(dim, pos, KEY_AMMO, 0)
                if ammo <= 0:
                    return
            # 开火节奏也按坐标错峰，避免同一片炮塔齐射
            if (self.processTick + salt) % FIRE_INTERVAL != 0:
                return

            center = (x + 0.5, y + 0.9, z + 0.5)
            target = self._findTarget(dim, center, mode)
            if target is None:
                return
            targetId, targetPos = target
            if self._fire(dim, pos, center, targetPos, targetId) and not UNLIMITED_AMMO:
                self._write(dim, pos, KEY_AMMO, ammo - 1)
        except Exception:
            # 单个方块的异常不要刷屏
            pass

    def OnBlockUse(self, args):
        if args.get("blockName") != BLOCK_NAME:
            return
        args["cancel"] = True

        playerId = args.get("playerId")
        if not playerId:
            return
        if self._handName(playerId) == REMOTE_ITEM:
            # 手持遥控器右键炮塔 = 绑定，交给 OnItemUseOn，这里不切模式
            return
        pos = (args["x"], args["y"], args["z"])
        key = (playerId, pos)
        self.useSeq += 1
        if self.useSeq - self.lastUse.get(key, -1000) < USE_THROTTLE:
            return
        self.lastUse[key] = self.useSeq

        dim = args.get("dimensionId", 0)
        if self._tryLoad(playerId, dim, pos):
            return

        mode = (self._read(dim, pos, KEY_MODE, MODE_MONSTER) + 1) % MODE_COUNT
        self._write(dim, pos, KEY_MODE, mode)
        ammo = self._read(dim, pos, KEY_AMMO, 0)
        self._say(playerId, u"§e炮塔：%s ｜ %s" % (MODE_TEXT.get(mode, u"?"), _ammoText(ammo)))

    # ------------------------------------------------------------------ #
    # 遥控器
    # ------------------------------------------------------------------ #
    def OnItemUseOn(self, args):
        """手持遥控器对方块使用：点炮塔=绑定/远程补弹，点其它方块=远程切模式。"""
        if _itemName(args.get("itemDict")) != REMOTE_ITEM:
            return
        playerId = args.get("entityId") or args.get("playerId")
        if not playerId:
            return
        # 遥控器不走原版使用逻辑（不吃饭、不点火、不开箱子）
        args["ret"] = True
        args["cancel"] = True

        now = time.time()
        if now - self.remoteGuard.get(playerId, 0.0) < REMOTE_THROTTLE:
            return
        self.remoteGuard[playerId] = now

        dim = args.get("dimensionId", args.get("dimension", 0))
        pos = (args.get("x"), args.get("y"), args.get("z"))
        if args.get("blockName") == BLOCK_NAME:
            if self._readBind(playerId) == (dim, pos):
                # 已经是绑定目标：再点它就是在补弹，而不是解绑
                self._remoteRefill(playerId, dim, pos)
            else:
                self._toggleBind(playerId, dim, pos)
        else:
            self._remoteCycle(playerId)

    def _handName(self, playerId):
        try:
            comp = FACTORY.CreateItem(playerId)
            itemType = serverApi.GetMinecraftEnum().ItemPosType.CARRIED
            return _itemName(comp.GetPlayerItem(itemType, 0, True))
        except Exception:
            return ""

    def _toggleBind(self, playerId, dim, pos):
        old = self._readBind(playerId)
        if not self._writeBind(playerId, (dim, pos)):
            self._say(playerId, u"§c遥控器：绑定失败，请重试")
            return
        mode = self._read(dim, pos, KEY_MODE, MODE_MONSTER)
        ammo = self._read(dim, pos, KEY_AMMO, 0)
        head = u"§a遥控器已改绑" if old else u"§a遥控器已绑定"
        self._say(playerId, u"%s炮塔 (%d, %d, %d) ｜ %s ｜ %s"
                  % (head, pos[0], pos[1], pos[2], MODE_TEXT.get(mode, u"?"), _ammoText(ammo)))
        if UNLIMITED_AMMO:
            self._say(playerId, u"§7点其它方块 = 切换模式（弹药无限，无需补弹）")
        else:
            self._say(playerId, u"§7再点这座炮塔 = 远程补弹 ｜ 点其它方块 = 切换模式")

    def _remoteRefill(self, playerId, dim, pos):
        """远程补弹：从玩家背包扣箭写进炮塔弹药，规则与手动装填一致。"""
        if UNLIMITED_AMMO:
            self._say(playerId, u"§e遥控器：炮塔弹药无限，无需补弹")
            return
        ammo = self._read(dim, pos, KEY_AMMO, 0)
        space = MAX_AMMO - ammo
        if space <= 0:
            self._say(playerId, u"§c遥控器：炮塔弹药已满（%d/%d）" % (ammo, MAX_AMMO))
            return

        need = int(math.ceil(space / float(AMMO_PER_ARROW)))
        taken = self._takeArrows(playerId, need)
        if taken <= 0:
            self._say(playerId, u"§c遥控器：背包里没有箭（%d/%d），无法远程补弹"
                      % (ammo, MAX_AMMO))
            return

        add = taken * AMMO_PER_ARROW
        if add > space:
            add = space
        self._write(dim, pos, KEY_AMMO, ammo + add)
        self._say(playerId, u"§a远程补弹：-%d 支箭，弹药 %d/%d"
                  % (taken, ammo + add, MAX_AMMO))

    def _takeArrows(self, playerId, need):
        """从背包（含快捷栏）按槽扣箭，返回实际扣到的支数。"""
        if need <= 0:
            return 0
        try:
            comp = FACTORY.CreateItem(playerId)
            inv = serverApi.GetMinecraftEnum().ItemPosType.INVENTORY
        except Exception:
            return 0

        got = 0
        for slot in range(INV_SLOTS):
            if got >= need:
                break
            try:
                item = comp.GetPlayerItem(inv, slot, True)
            except Exception:
                continue
            if not item:
                continue
            if _itemName(item) != ARROW_ITEM:
                continue
            try:
                count = int(item.get("count", 0))
            except Exception:
                count = 0
            if count <= 0:
                continue
            take = min(count, need - got)
            try:
                comp.SetInvItemNum(slot, count - take, inv)
            except Exception:
                continue
            got += take
        return got

    def _remoteCycle(self, playerId):
        bind = self._readBind(playerId)
        if bind is None:
            self._say(playerId, u"§c遥控器未绑定：手持遥控器右键炮台进行绑定")
            return
        dim, pos = bind

        try:
            playerPos = FACTORY.CreatePos(playerId).GetPos()
        except Exception:
            playerPos = None
        if not playerPos:
            self._say(playerId, u"§c遥控器：读不到自己的位置")
            return

        try:
            playerDim = FACTORY.CreateDimension(playerId).GetEntityDimensionId()
        except Exception:
            playerDim = dim
        if playerDim != dim:
            self._say(playerId, u"§c遥控器：绑定的炮塔在另一个维度")
            return

        # 先校验方块还在不在，再校验距离，避免对着空气发指令
        if not self._isTurretBlock(dim, pos):
            self._writeBind(playerId, None)
            self._say(playerId, u"§c遥控器：目标炮塔已不存在，已自动解除绑定")
            return

        d2 = _dist2(playerPos, (pos[0] + 0.5, pos[1] + 0.5, pos[2] + 0.5))
        if d2 > REMOTE_RANGE_SQ:
            self._say(playerId, u"§c遥控器：超出遥控距离（%d 格，上限 %d 格）"
                      % (int(math.sqrt(d2)), int(REMOTE_RANGE)))
            return

        mode = (self._read(dim, pos, KEY_MODE, MODE_MONSTER) + 1) % MODE_COUNT
        self._write(dim, pos, KEY_MODE, mode)
        ammo = self._read(dim, pos, KEY_AMMO, 0)
        self._say(playerId, u"§e炮塔遥控：%s ｜ %s ｜ 距 %d 格"
                  % (MODE_TEXT.get(mode, u"?"), _ammoText(ammo), int(math.sqrt(d2))))

    def _isTurretBlock(self, dim, pos):
        try:
            block = self.blockInfo.GetBlockNew(pos, dim)
            if block:
                return block.get("name") == BLOCK_NAME
        except Exception:
            pass
        return False

    def _readBind(self, playerId):
        """读绑定：返回 (dim, (x,y,z)) 或 None。"""
        try:
            raw = FACTORY.CreateExtraData(playerId).GetExtraData(KEY_BIND)
        except Exception:
            return None
        if not raw:
            return None
        try:
            parts = str(raw).split(",")
            if len(parts) != 4:
                return None
            return (int(parts[0]), (int(parts[1]), int(parts[2]), int(parts[3])))
        except Exception:
            return None

    def _writeBind(self, playerId, bind):
        try:
            comp = FACTORY.CreateExtraData(playerId)
            if bind is None:
                comp.SetExtraData(KEY_BIND, "")
            else:
                dim, pos = bind
                comp.SetExtraData(KEY_BIND, "%d,%d,%d,%d" % (dim, pos[0], pos[1], pos[2]))
            return True
        except Exception:
            return False

    # ------------------------------------------------------------------ #
    # 装填
    # ------------------------------------------------------------------ #
    def _tryLoad(self, playerId, dim, pos):
        """手持箭时装填，返回 True 表示这次右键被当作装填处理。"""
        itemComp = None
        itemType = None
        itemDict = None
        try:
            itemComp = FACTORY.CreateItem(playerId)
            itemType = serverApi.GetMinecraftEnum().ItemPosType.CARRIED
            itemDict = itemComp.GetPlayerItem(itemType, 0, True)
        except Exception:
            itemDict = None
        if not itemDict:
            return False

        name = itemDict.get("newItemName") or itemDict.get("itemName") or ""
        if name != "minecraft:arrow":
            return False

        if UNLIMITED_AMMO:
            self._say(playerId, u"§e炮塔：弹药无限，无需装填")
            return True

        ammo = self._read(dim, pos, KEY_AMMO, 0)
        space = MAX_AMMO - ammo
        if space <= 0:
            self._say(playerId, u"§c炮塔：弹药已满（%d/%d）" % (ammo, MAX_AMMO))
            return True

        try:
            count = int(itemDict.get("count", 0))
        except Exception:
            count = 0
        if count <= 0:
            return False

        canTake = int(math.ceil(space / float(AMMO_PER_ARROW)))
        take = min(count, canTake)
        add = take * AMMO_PER_ARROW
        if add > space:
            add = space

        try:
            itemComp.SetInvItemNum(0, count - take, itemType)
        except Exception:
            return False

        self._write(dim, pos, KEY_AMMO, ammo + add)
        self._say(playerId, u"§a炮塔装填：-%d 支箭，弹药 %d/%d" % (take, ammo + add, MAX_AMMO))
        return True

    # ------------------------------------------------------------------ #
    # 索敌
    # ------------------------------------------------------------------ #
    def _findTarget(self, dim, center, mode):
        r = SCAN_RADIUS
        start = (center[0] - r, center[1] - r, center[2] - r)
        end = (center[0] + r, center[1] + r, center[2] + r)
        try:
            entities = self.game.GetEntitiesInSquareArea(None, start, end, dim)
        except Exception:
            return None
        if not entities:
            return None

        bestId = None
        bestPos = None
        bestD = SCAN_RADIUS_SQ
        for entityId in entities:
            if not entityId:
                continue
            typeStr = self._typeStr(entityId)
            if not typeStr:
                continue
            if typeStr == PLAYER_TYPE:
                if mode != MODE_ALL:
                    continue
            else:
                if not self._isMob(entityId, typeStr):
                    continue
                if mode == MODE_MONSTER and typeStr not in MONSTERS:
                    continue

            pos = self._entityPos(entityId)
            if pos is None:
                continue
            d = _dist2(pos, center)
            if d < 1.0:          # 贴在炮塔上/里面的实体不打，避免自伤式抖动
                continue
            if d < bestD:
                bestD = d
                bestId = entityId
                bestPos = pos
        if bestId is None:
            return None
        return (bestId, bestPos)

    def _isMob(self, entityId, typeStr):
        try:
            enum = serverApi.GetMinecraftEnum().EntityType
            etype = FACTORY.CreateEngineType(entityId).GetEngineType()
            return (etype & enum.Mob) == enum.Mob
        except Exception:
            # 拿不到类型位时，按"非玩家、非已知非生物"兜底
            return typeStr not in ("minecraft:item", "minecraft:xp_orb", "minecraft:arrow")

    # ------------------------------------------------------------------ #
    # 开火
    # ------------------------------------------------------------------ #
    def _fire(self, dim, pos, center, targetPos, targetId):
        spawner = self._nearestPlayer(dim, center)
        if not spawner:
            return False

        dx = targetPos[0] - center[0]
        dy = targetPos[1] - center[1]
        dz = targetPos[2] - center[2]
        length = math.sqrt(dx * dx + dy * dy + dz * dz) or 1.0
        direction = (dx / length, dy / length, dz / length)

        muzzle = (
            center[0] + direction[0] * 0.55,
            center[1] + direction[1] * 0.55,
            center[2] + direction[2] * 0.55,
        )
        param = {
            "position": muzzle,
            "direction": direction,
            "power": ARROW_POWER,
            "gravity": ARROW_GRAVITY,
            "damage": ARROW_DAMAGE,
            "isDamageOwner": False,
            "targetId": targetId,
        }
        try:
            projectileId = self.projComp.CreateProjectileEntity(spawner, "minecraft:arrow", param)
        except Exception:
            return False
        if projectileId in (None, "", "-1"):
            return False
        self.trackedArrows.append((projectileId, self.processTick))
        return True

    def _sweepArrows(self):
        """清理炮塔射出的箭：打中目标会被引擎回收，没打中的插在地上，到期统一销毁。"""
        if not self.trackedArrows:
            return
        now = self.processTick
        alive = []
        for projectId, born in self.trackedArrows:
            if now - born < ARROW_LIFETIME:
                alive.append((projectId, born))
                continue
            try:
                self.game.DestroyEntity(projectId)
            except Exception:
                # 已经被引擎回收（命中目标/玩家拾取）的箭销毁会失败，忽略即可
                pass
        self.trackedArrows = alive

    def _nearestPlayer(self, dim, center):
        r = SPAWNER_RADIUS
        start = (center[0] - r, center[1] - r, center[2] - r)
        end = (center[0] + r, center[1] + r, center[2] + r)
        try:
            entities = self.game.GetEntitiesInSquareArea(None, start, end, dim)
        except Exception:
            return None
        best = None
        bestD = r * r
        for entityId in entities:
            if not entityId:
                continue
            if self._typeStr(entityId) != PLAYER_TYPE:
                continue
            pos = self._entityPos(entityId)
            if pos is None:
                continue
            d = _dist2(pos, center)
            if d < bestD:
                bestD = d
                best = entityId
        return best

    # ------------------------------------------------------------------ #
    # 组件缓存
    # ------------------------------------------------------------------ #
    def _typeStr(self, entityId):
        cached = self.typeCache.get(entityId)
        if cached is not None:
            return cached
        try:
            value = FACTORY.CreateEngineType(entityId).GetEngineTypeStr()
        except Exception:
            value = None
        if len(self.typeCache) > 512:
            self.typeCache.clear()
        self.typeCache[entityId] = value
        return value

    def _entityPos(self, entityId):
        cached = self.posCache.get(entityId)
        if cached is not None:
            return cached
        try:
            value = FACTORY.CreatePos(entityId).GetPos()
        except Exception:
            value = None
        if len(self.posCache) > 512:
            self.posCache.clear()
        self.posCache[entityId] = value
        return value

    # ------------------------------------------------------------------ #
    # 方块实体数据
    # ------------------------------------------------------------------ #
    def _read(self, dim, pos, key, default):
        try:
            data = self.blockEntity.GetBlockEntityData(dim, pos)
            if data is not None:
                value = data[key]
                return int(value)
        except Exception:
            pass
        return default

    def _write(self, dim, pos, key, value):
        try:
            data = self.blockEntity.GetBlockEntityData(dim, pos)
            if data is not None:
                data[key] = int(value)
        except Exception:
            pass

    def _say(self, playerId, text):
        try:
            self.msgComp.NotifyOneMessage(playerId, text, u"§e")
        except Exception:
            pass

    def Destroy(self):
        self.posCache.clear()
        self.typeCache.clear()
        self.lastUse.clear()
        self.remoteGuard.clear()
