# -*- coding: utf-8 -*-
"""
传送带模组 - 服务端逻辑（四方向分体方块）

方块：conveyor:belt_north / belt_south / belt_east / belt_west
      每个方块自带固定方向：北 = -Z，南 = +Z，东 = +X，西 = -X。
      方向由方块本身决定，顶面贴图（含滚动动画）与推动方向永远一致，
      不需要读朝向，也不会出现"箭头往前、东西往后"。

操作：空手右键循环切换速度档
      停止 -> 1 档 -> 2 档 -> 3 档 -> 停止（档位存方块实体数据，随存档持久化）
      要换方向，直接放另一个方向的传送带即可（4 个方块对应 4 个方向）。

物件物流：
      掉落物会被单独识别并按专门参数处理；
      传送带正下方如果是容器（漏斗 / 箱子 / 木桶 / 投掷器 / 发射器 / 潜影盒），
      这一段就是"卸料点"：物品不再被继续推动，而是直接搬进该容器的空槽位并销毁实体。
      容器满了就留在带上等待，容器一有空位立刻入库。
      经典用法：传送带末端下方放漏斗，漏斗再接入箱子。

其他细节：
  * 站在带上且脚底贴着上表面的实体才会被推动，旁边的生物不受影响；
  * 沿垂直于运行方向做轻度居中吸附，长距离输送不会越跑越偏；掉落物还会做位置修正；
  * 正前方被实心方块挡住时不再推动，避免把实体死死顶在墙里；
    前方是任意方向的传送带时不算挡道，可以接力或拐弯输送；
  * tick 处理按坐标哈希错峰，避免一条长带上所有方块同 tick 集中计算。
"""

import mod.server.extraServerApi as serverApi

ServerSystem = serverApi.GetServerSystemCls()

LEVEL_ID = serverApi.GetLevelId()
FACTORY = serverApi.GetEngineCompFactory()

# 方块 -> 推送方向 (dx, dz)
BLOCK_DIRS = {
    "conveyor:belt_north": (0.0, -1.0),
    "conveyor:belt_south": (0.0, 1.0),
    "conveyor:belt_east": (1.0, 0.0),
    "conveyor:belt_west": (-1.0, 0.0),
}
BELT_BLOCKS = tuple(BLOCK_DIRS.keys())

LEVEL_KEY = "level"

# 每 2 tick 处理一次（10 次/秒），降低高频 tick 开销
PROCESS_INTERVAL = 2
# 索引即速度档，0 档表示不推
SPEED_TABLE = (0.0, 0.10, 0.18, 0.28)
MAX_LEVEL = len(SPEED_TABLE) - 1
DEFAULT_LEVEL = 1

# 右键事件每 tick 都会触发，加节流，避免连点瞬间转好几圈
USE_THROTTLE = 8

TOP_OFFSET = 0.5        # 方块上表面高度
CENTER_PULL = 0.30      # 生物/玩家居中吸附强度
CENTER_MAX = 0.06       # 生物/玩家居中吸附单次上限
ITEM_CENTER_PULL = 0.50 # 掉落物居中更强，物品最容易跑偏
ITEM_CENTER_MAX = 0.09
ITEM_SNAP_MAX = 0.05    # 掉落物位置修正上限（直接往中线拉一点）

AIR_BLOCKS = ("minecraft:air", "minecraft:cave_air", "minecraft:void_air")

# SpawnItemToContainer 支持写入的容器方块
CONTAINER_BLOCKS = (
    "minecraft:hopper",
    "minecraft:chest",
    "minecraft:trapped_chest",
    "minecraft:shulker_box",
    "minecraft:barrel",
    "minecraft:dropper",
    "minecraft:dispenser",
)

# 掉落物实体标识
ITEM_ENTITY_IDS = ("minecraft:item",)

# 方块查询缓存的有效 tick 数（tick 事件是 20/秒）
BLOCK_CACHE_TTL = 40
BLOCK_CACHE_LIMIT = 1024

# 推送方向 -> 中文方位（用于右键提示）
DIR_NAME = {
    (0.0, 1.0): u"南",
    (0.0, -1.0): u"北",
    (-1.0, 0.0): u"西",
    (1.0, 0.0): u"东",
}


def _emptyItemSlot(itemDict):
    """判断容器槽位是否空着"""
    if not itemDict:
        return True
    if itemDict.get("itemName") in (None, "", "minecraft:air"):
        return True
    try:
        return int(itemDict.get("count", 0)) <= 0
    except Exception:
        return True


class ConveyorServerSystem(ServerSystem):

    def __init__(self, namespace, systemName):
        ServerSystem.__init__(self, namespace, systemName)
        self.blockInfo = FACTORY.CreateBlockInfo(LEVEL_ID)
        self.blockEntity = FACTORY.CreateBlockEntityData(LEVEL_ID)
        self.game = FACTORY.CreateGame(LEVEL_ID)
        self.itemComp = FACTORY.CreateItem(LEVEL_ID)
        self.msgComp = FACTORY.CreateMsg(LEVEL_ID)
        self.processTick = 0
        self.useSeq = 0
        self.lastUse = {}
        # 缓存：实体组件 / 实体类型 / 方块查询结果，避免高频 tick 里反复创建与读取
        self.posCache = {}
        self.motionCache = {}
        self.typeCache = {}
        self.blockCache = {}

        engineNs = serverApi.GetEngineNamespace()
        engineSys = serverApi.GetEngineSystemName()
        self.ListenForEvent(engineNs, engineSys, "ServerBlockEntityTickEvent", self, self.OnBlockEntityTick)
        self.ListenForEvent(engineNs, engineSys, "ServerBlockUseEvent", self, self.OnBlockUse)
        self.ListenForEvent(engineNs, engineSys, "ServerPlaceBlockEntityEvent", self, self.OnPlaceBlockEntity)

    # ------------------------------------------------------------------ #
    # 事件
    # ------------------------------------------------------------------ #
    def OnPlaceBlockEntity(self, args):
        """玩家放下传送带时写入默认档位（1 档）。"""
        if args.get("blockName") not in BLOCK_DIRS:
            return
        pos = (args["posX"], args["posY"], args["posZ"])
        self._writeLevel(args["dimension"], pos, DEFAULT_LEVEL)

    def OnBlockEntityTick(self, args):
        try:
            dirVec = BLOCK_DIRS.get(args.get("blockName"))
            if dirVec is None:
                return
            self.processTick += 1
            # 用坐标哈希错峰，避免相邻传送带挤在同一个 tick 里一起算
            salt = (args["posX"] * 31 + args["posY"] * 17 + args["posZ"] * 13) & 0xFFFF
            if (self.processTick + salt) % PROCESS_INTERVAL != 0:
                return

            dim = args["dimension"]
            x = args["posX"]
            y = args["posY"]
            z = args["posZ"]
            pos = (x, y, z)

            level = self._readLevel(dim, pos)
            if level <= 0:
                return
            speed = SPEED_TABLE[level]
            dx, dz = dirVec

            # 正前方被挡住就不推了，否则实体会被顶着贴墙抖动
            if self._blockedAhead(dim, x, y, z, dx, dz):
                return

            # 卸料点：正下方的容器
            containerPos = self._containerBelow(dim, x, y, z)

            # 检测框下沿特意压到上表面以下：掉落物实体很扁，
            # 它的包围盒底面刚好贴着 y+0.5，若下沿正好等于 y+0.5 会判定为"仅表面相接"而漏掉
            start = (x + 0.03, y + TOP_OFFSET - 0.30, z + 0.03)
            end = (x + 0.97, y + TOP_OFFSET + 1.1, z + 0.97)
            entities = self.game.GetEntitiesInSquareArea(None, start, end, dim)
            if not entities:
                return
            for entityId in entities:
                if self._isItemEntity(entityId):
                    # 掉落物：先尝试入库，成功了就不再推它
                    if containerPos and self._insertIntoContainer(entityId, containerPos, dim):
                        continue
                    self._pushItem(entityId, dx, dz, speed, x, y, z)
                else:
                    self._pushEntity(entityId, dx, dz, speed, x, y, z)
        except Exception:
            # tick 里吞异常，别让单个方块的问题刷屏
            pass

    def OnBlockUse(self, args):
        """右键：循环切换 停止 / 1 / 2 / 3 档。"""
        dirVec = BLOCK_DIRS.get(args.get("blockName"))
        if dirVec is None:
            return
        # 拦掉与原版交互/放置方块的逻辑，右键只用来切档位
        args["cancel"] = True

        playerId = args.get("playerId")
        if not playerId:
            return
        pos = (args["x"], args["y"], args["z"])
        key = (playerId, pos)
        self.useSeq += 1
        if self.useSeq - self.lastUse.get(key, -1000) < USE_THROTTLE:
            return
        self.lastUse[key] = self.useSeq

        dim = args.get("dimensionId", 0)
        level = (self._readLevel(dim, pos) + 1) % (MAX_LEVEL + 1)
        self._writeLevel(dim, pos, level)
        try:
            self.msgComp.NotifyOneMessage(playerId, self._levelText(dirVec, level), u"§e")
        except Exception:
            pass

    def _levelText(self, dirVec, level):
        if level <= 0:
            return u"传送带：已停止"
        return u"传送带：%d 档（往%s送）" % (level, DIR_NAME.get(dirVec, u"?"))

    # ------------------------------------------------------------------ #
    # 掉落物 -> 容器
    # ------------------------------------------------------------------ #
    def _isItemEntity(self, entityId):
        cached = self.typeCache.get(entityId)
        if cached is not None:
            return cached == "item"
        typeStr = None
        try:
            typeStr = FACTORY.CreateEngineType(entityId).GetEngineTypeStr()
        except Exception:
            typeStr = None
        if typeStr:
            isItem = str(typeStr) in ITEM_ENTITY_IDS
        else:
            # 兜底：直接读掉落物
            try:
                isItem = self.itemComp.GetDroppedItem(entityId) is not None
            except Exception:
                isItem = False
        if len(self.typeCache) > 512:
            self.typeCache.clear()
        self.typeCache[entityId] = "item" if isItem else "entity"
        return isItem

    def _insertIntoContainer(self, entityId, containerPos, dim):
        """把掉落物搬进容器并销毁掉落物实体，成功返回 True。"""
        try:
            itemDict = self.itemComp.GetDroppedItem(entityId)
            if not itemDict:
                return False
            try:
                size = int(self.itemComp.GetContainerSize(containerPos, dim))
            except Exception:
                size = 0
            if size <= 0:
                return False

            targetSlot = -1
            for slot in range(size):
                existing = self.itemComp.GetContainerItem(containerPos, slot, dim)
                if _emptyItemSlot(existing):
                    targetSlot = slot
                    break
            if targetSlot < 0:
                return False  # 容器满了：留在带上等下一轮

            if not self.itemComp.SpawnItemToContainer(itemDict, targetSlot, containerPos, dim):
                return False
            self.DestroyEntity(entityId)
            return True
        except Exception:
            return False

    # ------------------------------------------------------------------ #
    # 实体推动
    # ------------------------------------------------------------------ #
    def _pushEntity(self, entityId, dx, dz, speed, blockX, blockY, blockZ):
        self._trimCaches()
        posComp = self.posCache.get(entityId)
        if posComp is None:
            posComp = FACTORY.CreatePos(entityId)
            self.posCache[entityId] = posComp
        footPos = posComp.GetFootPos()
        if not footPos:
            return
        # 只推真正踩在传送带上表面的实体，旁边站着的生物不受影响
        if footPos[1] < blockY + TOP_OFFSET - 0.15 or footPos[1] > blockY + TOP_OFFSET + 0.25:
            return
        vx, vz = self._motionWithCentering(dx, dz, speed, footPos, blockX, blockZ,
                                           CENTER_PULL, CENTER_MAX)
        self._applyMotion(entityId, vx, vz)

    def _pushItem(self, entityId, dx, dz, speed, blockX, blockY, blockZ):
        self._trimCaches()
        posComp = self.posCache.get(entityId)
        if posComp is None:
            posComp = FACTORY.CreatePos(entityId)
            self.posCache[entityId] = posComp
        footPos = posComp.GetFootPos()
        if not footPos:
            return
        # 掉落物实体很扁，脚点会低一截，判定窗口放宽
        if footPos[1] < blockY + TOP_OFFSET - 0.35 or footPos[1] > blockY + TOP_OFFSET + 0.30:
            return

        vx, vz = self._motionWithCentering(dx, dz, speed, footPos, blockX, blockZ,
                                           ITEM_CENTER_PULL, ITEM_CENTER_MAX)

        # 掉落物没有客户端操控，可以直接把位置往中线拉一点，防止被甩出带子
        perpX = -dz
        perpZ = dx
        lateral = (blockX + 0.5 - footPos[0]) * perpX + (blockZ + 0.5 - footPos[2]) * perpZ
        if abs(lateral) > 0.02:
            snap = lateral * ITEM_CENTER_PULL
            if snap > ITEM_SNAP_MAX:
                snap = ITEM_SNAP_MAX
            elif snap < -ITEM_SNAP_MAX:
                snap = -ITEM_SNAP_MAX
            try:
                posComp.SetFootPos((footPos[0] + perpX * snap, footPos[1], footPos[2] + perpZ * snap))
            except Exception:
                pass
        self._applyMotion(entityId, vx, vz)

    def _motionWithCentering(self, dx, dz, speed, footPos, blockX, blockZ, pull, cap):
        perpX = -dz
        perpZ = dx
        offset = (blockX + 0.5 - footPos[0]) * perpX + (blockZ + 0.5 - footPos[2]) * perpZ
        lateral = offset * pull
        if lateral > cap:
            lateral = cap
        elif lateral < -cap:
            lateral = -cap
        return dx * speed + perpX * lateral, dz * speed + perpZ * lateral

    def _applyMotion(self, entityId, vx, vz):
        motionComp = self.motionCache.get(entityId)
        if motionComp is None:
            motionComp = FACTORY.CreateActorMotion(entityId)
            self.motionCache[entityId] = motionComp
        motion = motionComp.GetMotion()
        vy = motion[1] if motion else 0.0
        motionComp.SetMotion((vx, vy, vz))

    def _trimCaches(self):
        if len(self.posCache) > 512:
            self.posCache.clear()
            self.motionCache.clear()

    # ------------------------------------------------------------------ #
    # 方块查询
    # ------------------------------------------------------------------ #
    def _cachedBlockName(self, dim, pos):
        key = (dim, pos[0], pos[1], pos[2])
        hit = self.blockCache.get(key)
        if hit and self.processTick - hit[0] < BLOCK_CACHE_TTL:
            return hit[1]
        name = ""
        try:
            block = self.blockInfo.GetBlockNew(pos, dim)
            if block:
                name = block.get("name", "") or ""
        except Exception:
            name = ""
        if len(self.blockCache) > BLOCK_CACHE_LIMIT:
            self.blockCache.clear()
        self.blockCache[key] = (self.processTick, name)
        return name

    def _blockedAhead(self, dim, x, y, z, dx, dz):
        fx = x + int(round(dx))
        fz = z + int(round(dz))
        if fx == x and fz == z:
            return False
        name = self._cachedBlockName(dim, (fx, y, fz))
        if not name or name in AIR_BLOCKS:
            return False
        # 前方接另一条传送带不算挡道（任意方向都允许接力或拐弯）
        return name not in BELT_BLOCKS

    def _containerBelow(self, dim, x, y, z):
        """正下方是容器就返回容器坐标，否则返回 None。"""
        pos = (x, y - 1, z)
        name = self._cachedBlockName(dim, pos)
        return pos if name in CONTAINER_BLOCKS else None

    def _readLevel(self, dim, pos):
        try:
            data = self.blockEntity.GetBlockEntityData(dim, pos)
            if data is not None:
                level = int(data[LEVEL_KEY])
                if 0 <= level <= MAX_LEVEL:
                    return level
        except Exception:
            pass
        return DEFAULT_LEVEL

    def _writeLevel(self, dim, pos, level):
        try:
            data = self.blockEntity.GetBlockEntityData(dim, pos)
            if data is not None:
                data[LEVEL_KEY] = int(level)
        except Exception:
            pass

    # ------------------------------------------------------------------ #
    def Destroy(self):
        self.posCache.clear()
        self.motionCache.clear()
        self.typeCache.clear()
        self.blockCache.clear()
        self.lastUse.clear()
        ServerSystem.Destroy(self)
