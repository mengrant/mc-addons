# -*- coding: utf-8 -*-
from mod.common.mod import Mod
import mod.server.extraServerApi as serverApi

MOD_NAME = "ConveyorMod"
SERVER_SYSTEM_NAME = "ConveyorServerSystem"
SERVER_SYSTEM_CLS_PATH = "conveyorScripts.conveyorServerSystem.ConveyorServerSystem"


@Mod.Binding(name=MOD_NAME, version="0.0.6")
class ConveyorMod(object):

    def __init__(self):
        pass

    @Mod.InitServer()
    def ConveyorServerInit(self):
        serverApi.RegisterSystem(MOD_NAME, SERVER_SYSTEM_NAME, SERVER_SYSTEM_CLS_PATH)

    @Mod.DestroyServer()
    def ConveyorServerDestroy(self):
        pass
